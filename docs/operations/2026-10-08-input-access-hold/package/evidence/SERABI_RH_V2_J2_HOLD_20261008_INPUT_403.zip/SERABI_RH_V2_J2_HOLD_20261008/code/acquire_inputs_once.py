import concurrent.futures, hashlib, json, pathlib, time, urllib.request
root=pathlib.Path(__file__).resolve().parent
(root/'inputs').mkdir(exist_ok=True)
def transfer(s):
    start=time.monotonic(); target=root/'inputs'/s['name']; h=hashlib.sha256(); n=0
    record={k:v for k,v in s.items() if k!='download_url'}
    try:
        with urllib.request.urlopen(s['download_url'], timeout=45) as response, target.open('xb') as out:
            while block:=response.read(1024*1024):
                out.write(block); h.update(block); n+=len(block)
        record.update(actual_bytes=n, actual_sha256=h.hexdigest(), match=n==s['bytes'] and h.hexdigest()==s['sha256'])
    except Exception as error:
        record.update(error=type(error).__name__+': '+str(error), actual_bytes=n, match=False)
    record['wall_seconds']=time.monotonic()-start
    return record
spec=json.loads((root/'download_private.json').read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(transfer,spec))
(root/'INPUT_TRANSFER.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
raise SystemExit(0 if all(r['match'] for r in results) else 1)
