import hashlib, pathlib, sys
root=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
errors=[]; count=0
for line in (root/'MANIFEST.sha256').read_text().splitlines():
    expected, name=line.split('  ',1)
    target=(root/name).resolve()
    if not target.is_relative_to(root) or not target.is_file():
        errors.append(name); continue
    h=hashlib.sha256()
    with target.open('rb') as stream:
        while block:=stream.read(1024*1024): h.update(block)
    if h.hexdigest()!=expected: errors.append(name)
    count+=1
print({'checked':count,'mismatches':errors})
raise SystemExit(bool(errors))
