# HOLD package audit

License: CC BY-NC 4.0 for author-created files. No third-party archives are included.

This is a partial acquisition-failure package, not a V2 implementation or mathematical certificate. Read REPORT_KO.md and HOLD_STATUS.json first. All input SHA256 values are EXPECTED / UNVERIFIED. Input contents were not available.

The ZIP has one extraction root, SERABI_RH_V2_J2_HOLD_20261008. No split or assembly is needed. Run `python3 code/verify_manifest.py .` from that extraction root to independently verify the saved bytes against MANIFEST.sha256. This checks packaging only; it does not verify the unknown input hashes or any mathematical inequality.

code/acquire_inputs_once.py preserves the actual one-attempt acquisition helper. It requires a fresh private `download_private.json` containing authenticated transient download references, which is intentionally excluded. Do not execute it as an automatic retry. It contains no V2 numerical action or source DFT.

No source archive, nested cache, X40/Y40, action producer, action certificate, kernel result or reusable node/checkpoint is included. EXTERNAL_DEPENDENCIES.json lists the four original public Drive file URLs, expected sizes/hashes and requested restore roots. The nested dependency map and dependency licenses remain uninspected because its archive could not be downloaded.

Expected audit outcome: HOLD-INPUT-DOWNLOAD-HTTP-403, pilot attempt count 0. Escalating this package to PASS-PILOT, delta64 or RH proof is invalid. Remote upload/readback results are recorded separately to avoid altering these immutable packaged files after upload.
